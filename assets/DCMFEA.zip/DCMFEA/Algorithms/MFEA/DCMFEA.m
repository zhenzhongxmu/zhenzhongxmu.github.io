function res=DCMFEA(Problem,popSize,MaxIt,T_parameter,group)
Nfor2=20;
    F(1) = struct('cdata',[],'colormap',[]);
    rmp=1; % Random mating probability
    muc = 1; % Distribution Index of SBX crossover operator
    mum = 1; % Distribution Index of Polynomial Mutation operator
    prob_vswap = 0; % Probability that certain pair of variables are swapped (uniform crossover-like) during SBX crossover. Change to prob_swap = 0.5 for enhanced global search at the cost of high chromosome disruption.
    for T=1:T_parameter(group,3)/T_parameter(group,2)
        fprintf(' %d',T);
        t = 2/T_parameter(group,1)*(T-1);   % next moment
        mainTask=Problem;
        auxiliaryTask=creatAuxiliaryTask(Problem);
        if T==1
            [POF,population]=MOMFEA_v1(t,mainTask,popSize-Nfor2,auxiliaryTask,Nfor2,rmp,MaxIt,muc,mum,prob_vswap);  
        else
         % [POF,population]=MOMFEA_v1(t,mainTask,popSize-Nfor2,auxiliaryTask,Nfor2,rmp,MaxIt,muc,mum,prob_vswap);  
          [POF,population]=MOMFEA_v1(t,mainTask,popSize-Nfor2,auxiliaryTask,Nfor2,rmp,MaxIt,muc,mum,prob_vswap,population);  
        end
        
        
        CPOF=getFesiableSolutions(t,POF,mainTask);
        %F=drawSolutions(t,POF,mainTask,CPOF,T,F);
        res{T}.turePOF=Problem.getCPF(400,t);  
        res{T}.POF=POF;
        res{T}.CPOF=CPOF;
    end
end




function testInstance=creatAuxiliaryTask(Problem)
    testInstance.getFesiableRegion=Problem.getFesiableRegion;
    testInstance.getUPF=Problem.getUPF;
    testInstance.getCPF=Problem.getCPF;
    testInstance.getObj=@getObj;
    testInstance.getBound=Problem.getBound;
    testInstance.M=2;
    testInstance.D=10;
    testInstance.LBound=zeros(1,testInstance.D);
    testInstance.UBound=ones(1,testInstance.D);

end

function PopObj=getObj(X,M,D,t,Problem)
    PopObj1=Problem.getObj(X,M,D,t);
    PopObj2=Problem.getCV(PopObj1,t);
    PopObj=[PopObj1];%,PopObj2];
end

