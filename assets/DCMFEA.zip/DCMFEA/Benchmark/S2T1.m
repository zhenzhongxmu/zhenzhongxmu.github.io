function testInstance=S2T1()
    testInstance.getFesiableRegion=@getFesiableRegion;
    testInstance.getUPF=@getUPF;
    testInstance.getCPF=@getCPF;
    testInstance.getObj=@getObj;
    testInstance.getCV=@getCV;
    testInstance.M=2;
    testInstance.D=10;
    testInstance.getBound=@getBound;
end

function [LBound,UBound]=getBound(t)
    testInstance.D=10;
    G=0.5*abs(sin(t));
    LBound=zeros(1,testInstance.D);
    UBound=ones(1,testInstance.D)*(1);
end
function CV=getCV(PopObj,t)
    G=0.5*abs(sin(t));
    CV1 =1.1+G-PopObj(:,1).^2-PopObj(:,2).^2;
    l2=0.5*pi-2*abs(atan(PopObj(:,2)./PopObj(:,1))-0.25*pi);
    CV2=(1+0.5*sin(6*l2)).^2-PopObj(:,1).^2-PopObj(:,2).^2;
    CV=[-CV1,-CV2];
end

function PopObj=getObj(X,M,D,t)
    G=1*abs(sin(t));
    g = 1 + 0.1*abs(sum(X(:,M:D)-G,2)).^0.5 ;
    PopObj(:,1) = X(:,1);
    PopObj(:,2) = g.*sqrt(1-PopObj(:,1));
end


function UPF=getUPF(N,t)    
    G=1*abs(sin(t));
    UPF(:,1)=0:1/N:1;
    UPF(:,2)=sqrt(1-UPF(:,1));
end

function R=getCPF(N,t)    %(0.5+abs(sin(t)/2))
    G=1*abs(sin(t));
    R(:,1)  = (0:1/(N-1):1)';
    R(:,2)  = sqrt(1-R(:,1));
    c1=1.1+G-R(:,1).^2-R(:,2).^2;
    R(c1<0,:)=[];
    l2=0.5*pi-2*abs(atan(R(:,2)./R(:,1))-0.25*pi);
    c2=(1+0.5*sin(6*l2)).^2-R(:,1).^2-R(:,2).^2;
    R(c2<0,:)=[];
    
end

function R=getFesiableRegion(N,t)
    G=1*abs(sin(t));
    [x,y] = meshgrid(linspace(0,1.5,N),linspace(0,1.5,N));
    z     = nan(size(x));
    fes1  =1.1+G-x.^2-y.^2 >= 0;
    l2=0.5*pi-2*abs(atan(y./x)-0.25*pi);
    fes2  = (1+0.5*sin(6*l2)).^2-x.^2-y.^2 >= 0;
    z(fes1 & fes2 & x+y.^2>=1) = 0;
    R.x=x;
    R.y=y;
    R.z=z; 
end