function testInstance=S2T4()
    testInstance.getFesiableRegion=@getFesiableRegion;
    testInstance.getUPF=@getUPF;
    testInstance.getCPF=@getCPF;
    testInstance.getCV=@getCV;
    testInstance.getObj=@getObj;
    testInstance.M=2;
    testInstance.D=10;
    testInstance.getBound=@getBound;
end
function [LBound,UBound]=getBound(t)
    testInstance.D=10;
    G=0.5*abs(sin(t));
    LBound=zeros(1,testInstance.D);
    UBound=ones(1,testInstance.D)*(1);
end
function CV=getCV(PopObj,t)
    G=0.6+0.3*abs(sin(t));
    k=(0.5-G)/-0.5;
    CV1 =G-k.*PopObj(:,1)-PopObj(:,2)-0.08*(sin(5*pi.*PopObj(:,1)));
    
    CV2=1-PopObj(:,1)-PopObj(:,2)-0.08*(sin(5*pi.*PopObj(:,1)));
    CV=[-CV1,CV2];
end

function PopObj=getObj(X,M,D,t)
    G=0.6+0.3*abs(sin(t));
    
    PopObj(:,1) = X(:,1);
    for i=1:size(PopObj,1)
        g = 1 + sum(X(i,M:D)-G,2).^2 ;
        g = 1 + 0.1*abs(sum(X(i,M:D)-G,2)).^0.5 ;
        if PopObj(i,1)>=0.5
            PopObj(i,2)=g*(1-PopObj(i,1)-0.08*(sin(5*pi*PopObj(i,1))));
        else
            k=(0.5-G)/-0.5;
            PopObj(i,2)=g*(G-k*PopObj(i,1)-0.08*(sin(5*pi*PopObj(i,1))));
        end
    end  
end


function UPF=getUPF(N,t)    
    G=0.6+0.3*abs(sin(t));
    UPF(:,1)=0:1/N:1;
    k=(0.5-G)/-0.5;
    for i=1:size(UPF,1)
        if UPF(i,1)>=0.5
            UPF(i,2)=1-UPF(i,1)-0.08*(sin(5*pi*UPF(i,1)));
        else
            k=(0.5-G)/-0.5;
            UPF(i,2)=G-k*UPF(i,1)-0.08*(sin(5*pi*UPF(i,1)));
        end
    end  
    UPF = rm_dominated(UPF);    
end

function R=getCPF(N,t)    %(0.5+abs(sin(t)/2))
    G=0.6+0.3*abs(sin(t));
    R(:,1)=0.5:1/N:1;
    R(:,2)=1-R(:,1)-0.08*(sin(5*pi*R(:,1)));     
    R = rm_dominated(R); 
end

function R=getFesiableRegion(N,t)
    [x,y] = meshgrid(linspace(0,1.5,N),linspace(0,1.5,N));
    z     = nan(size(x));
    G=0.6+0.3*abs(sin(t));

    k=(0.5-G)/-0.5;
    fes1=G-k*x-y-0.08*(sin(5*pi*x))>=0;
    fes2=1-x-y-0.08*(sin(5*pi*x))<=0;
   

    z(fes1 & fes2) = 0;
    R.x=x;
    R.y=y;
    R.z=z; 
end