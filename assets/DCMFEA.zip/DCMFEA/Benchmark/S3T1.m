function testInstance=S3T1()
    testInstance.getFesiableRegion=@getFesiableRegion;
    testInstance.getUPF=@getUPF;
    testInstance.getCPF=@getCPF;
    testInstance.getCV=@getCV;
    testInstance.getObj=@getObj;
    testInstance.M=2;
    testInstance.D=10;
    testInstance.getBound=@getBound;
end
function [LBound,UBound]=getBound(t)
    testInstance.D=10;
    G=0.5*abs(sin(t));
    LBound=zeros(1,testInstance.D);
    UBound=ones(1,testInstance.D)*(1);
end
function CV=getCV(PopObj,t)
    t=0.1;
    CV1 =1.1 - PopObj(:,1).^2 - PopObj(:,2).^2 + 0.125*sin(t+2*pi*(sqrt(2)*PopObj(:,2)-sqrt(2)*PopObj(:,1))).^4;
    CV2=1 - PopObj(:,1).^2 - PopObj(:,2).^2 + 0.125*sin(t+2*pi*(sqrt(2)*PopObj(:,2)-sqrt(2)*PopObj(:,1))).^4;
    CV=[-CV1,CV2];
end

function PopObj=getObj(X,M,D,t)
    G=1*abs(sin(t));
    g = 1 + sum(X(:,M:D)-G,2).^2 ;
    g = 1 + 0.1*abs(sum(X(:,M:D)-G,2)).^0.5 ;
    PopObj(:,1) = X(:,1);
    PopObj(:,2) = g.*sqrt(1-PopObj(:,1).^2);
end


function UPF=getUPF(N,t)    
    UPF(:,1)=0:1/N:1;
    UPF(:,2)=sqrt(1-UPF(:,1).^2);
end

function R=getCPF(N,t)    %(0.5+abs(sin(t)/2))
    t=0.1;
    R(:,1)  = (0:1/(N-1):1)';
    R(:,2)  = sqrt(1 - R(:,1).^2);
    invalid = (1-R(:,1).^2-R(:,2).^2+0.125*sin(t+2*pi*sqrt(2)*(R(:,2)-R(:,1))).^4) > 0;
    while any(invalid)
        R(invalid,:) = R(invalid,:).*1.001;
        invalid = (1-R(:,1).^2-R(:,2).^2+0.125*sin(t+2*pi*sqrt(2)*(R(:,2)-R(:,1))).^4) > 0;
    end
    invalid=1.1 - R(:,1).^2 - R(:,2).^2 + 0.125*sin(t+2*pi*(sqrt(2)*R(:,2)-sqrt(2)*R(:,1))).^4 <0;
    
   % invalid = R(:,1) + R(:,2) - 1.1 - (0.3+(sin(t)/2))*sin(t+0.75*pi*(sqrt(2)*R(:,2)-sqrt(2)*R(:,1))).^6 > 0;
   R(invalid,:)=[];
     R = rm_dominated(R);
end

function R=getFesiableRegion(N,t)
    t=0.1;
    [x,y] = meshgrid(linspace(0,1.5,N),linspace(0,1.5,N));
    z     = nan(size(x));
    fes1  = 1.1 - x.^2 - y.^2 + 0.125*sin(t+2*pi*(sqrt(2)*y-sqrt(2)*x)).^4 >= 0;
    fes2  = 1 - x.^2 - y.^2 + 0.125*sin(t+2*pi*(sqrt(2)*y-sqrt(2)*x)).^4 <= 0;
    z(fes2& fes1 & x.^2+y.^2>=1) = 0;
    R.x=x;
    R.y=y;
    R.z=z; 
end