function testInstance=S3T4()
    testInstance.getFesiableRegion=@getFesiableRegion;
    testInstance.getUPF=@getUPF;
    testInstance.getCPF=@getCPF;
    testInstance.getCV=@getCV;
    testInstance.getObj=@getObj;
    testInstance.M=2;
    testInstance.D=10;
    testInstance.getBound=@getBound;
end
function [LBound,UBound]=getBound(t)
    testInstance.D=10;
    G=1.712565+0.138755*sin(t);
    k=1-G;
    ub=(0-G)/k;
    LBound=zeros(1,testInstance.D);
    UBound=ones(1,testInstance.D)*(ub);
end
function CV=getCV(PopObj,t)
    G=1.712565+0.138755*sin(t);
    k=1-G;
    CV1 =-(3-0.7*PopObj(:,1).^2-PopObj(:,2)).*(3-2*PopObj(:,1).^2-PopObj(:,2));
    CV2=(3-0.325*PopObj(:,1).^2-PopObj(:,2)).*(3-7*PopObj(:,1).^2-PopObj(:,2));
    CV3=-(1.42+0.11*PopObj(:,1).^2-PopObj(:,2)).*(1.025-0.025*PopObj(:,1).^2-PopObj(:,2));
    CV4=(2.07-0.03*PopObj(:,1).^2-PopObj(:,2)).*(0.3+0.05*PopObj(:,1).^2-PopObj(:,2)) ;
    CV=[CV1,CV2,CV3,CV4];
end

function PopObj=getObj(X,M,D,t)
    G=1.712565+0.138755*sin(t);
    k=1-G;
    g = 1 + sum(X(:,M:D)-G,2).^2 ;
    g = 1 + 0.1*abs(sum(X(:,M:D)-G,2)).^0.5 ;
    PopObj(:,1) = X(:,1);
    PopObj(:,2) = g.*(G+k*PopObj(:,1));
end


function UPF=getUPF(N,t)    
    G=1.712565+0.138755*sin(t);
    k=1-G;
    ub=(0-G)/k;
    UPF(:,1)=0:1/N:ub;
    UPF(:,2)=G+k*UPF(:,1);
%     UPF(find(imag((:,2))))=[];
end

function R=getCPF(N,t)    %(0.5+abs(sin(t)/2))
   R(:,1)  = (0:1/(N-1):1)';
            R(:,2)  = 1 - R(:,1);
            R       = R./repmat(sqrt(sum(R.^2,2)/2),1,2);
            c1      = (3 - 0.7*R(:,1).^2 - R(:,2)).*(3 - 2*R(:,1).^2 - R(:,2));
            c2      = (3 - 0.625*R(:,1).^2 - R(:,2)).*(3 - 7*R(:,1).^2 - R(:,2));
            c3      = (1.42 + 0.11*R(:,1).^2 - R(:,2)).*(1.025 - 0.025*R(:,1).^2 - R(:,2));
            c4      = (2.07 - 0.03*R(:,1).^2 - R(:,2)).*(0.3 +0.05*R(:,1).^2 - R(:,2));
            invalid = c1<0 | c2>0 | c3<0 | c4>0;
            while any(invalid)
                R(invalid,:) = R(invalid,:).*1.001;
                R(any(R>2.2,2),:) = [];
                c1      = (3 - 0.7*R(:,1).^2 - R(:,2)).*(3 - 2*R(:,1).^2 - R(:,2));
                c2      = (3 - 0.625*R(:,1).^2 - R(:,2)).*(3 - 7*R(:,1).^2 - R(:,2));
                c3      = (1.42 + 0.11*R(:,1).^2 - R(:,2)).*(1.025 - 0.025*R(:,1).^2 - R(:,2));
                c4      = (2.07 - 0.03*R(:,1).^2 - R(:,2)).*(0.3 + 0.05*R(:,1).^2 - R(:,2));
                invalid = c1<0 | c2>0 | c3<0 | c4>0;
            end
            R = [R;1,1];
            R = rm_dominated(R);
%             R = R(NDSort(R,1)==1,:);
end

function R=getFesiableRegion(N,t)
 G=1.712565+0.138755*sin(t);
    k=1-G;
   
    
    [x,y] = meshgrid(linspace(0,4.1,N));
            z     = nan(size(x));
            fes1  = -(3-0.7*x.^2-y).*(3-2*x.^2-y) <= 0;
            fes2  = (3-0.325*x.^2-y).*(3-7*x.^2-y) <= 0;
            fes3  = -(1.42+0.11*x.^2-y).*(1.025-0.025*x.^2-y) <= 0;
            fes4  = (2.07-0.03*x.^2-y).*(0.3+0.05*x.^2-y) <= 0;
            z(fes1&fes2&fes3&fes4&y-G-k*x>=0) = 0;
          


    R.x=x;
    R.y=y;
    R.z=z; 
end