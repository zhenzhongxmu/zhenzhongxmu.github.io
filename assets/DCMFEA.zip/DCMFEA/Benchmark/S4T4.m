function testInstance=S4T4()
    testInstance.getFesiableRegion=@getFesiableRegion;
    testInstance.getUPF=@getUPF;
    testInstance.getCPF=@getCPF;
    testInstance.getCV=@getCV;
    testInstance.getObj=@getObj;
    testInstance.M=2;
    testInstance.D=10;
    testInstance.getBound=@getBound;
end
function [LBound,UBound]=getBound(t)
    testInstance.D=10;
    G=0.5*abs(sin(t));
    LBound=zeros(1,testInstance.D);
    UBound=ones(1,testInstance.D)*(1);
end
function CV=getCV(PopObj,t)
    G=0.5*abs(sin(t));
    CV1 =(1-0.8*PopObj(:,1)-PopObj(:,2)+0.08*sin(2*pi*(PopObj(:,2)-PopObj(:,1)/1.5))).*(1.8-1.125*PopObj(:,1)-PopObj(:,2)+0.08*sin(2*pi*(PopObj(:,2)/1.8-PopObj(:,1)/1.6)));
    CV2=-(1-0.625*PopObj(:,1)-PopObj(:,2)+0.08*sin(2*pi*(PopObj(:,2)-PopObj(:,1)/1.6))).*(1.4-0.875*PopObj(:,1)-PopObj(:,2)+0.08*sin(2*pi*(PopObj(:,2)/1.4-PopObj(:,1)/1.6))) ;
    CV=[CV1,CV2];
end

function PopObj=getObj(X,M,D,t)
    G=0.85+0.05*sin(t);
    g = 1 + sum(X(:,M:D)-G,2).^2 ;
    g = 1 + 0.1*abs(sum(X(:,M:D)-G,2)).^0.5 ;
    PopObj(:,1) = X(:,1);
    PopObj(:,2) = g.*(0.8- 0.8*PopObj(:,1) - 0.1*(sin(mod(t,4)*3.2*pi*PopObj(:,1))));
end


function UPF=getUPF(N,t)    
    G=0.85+0.05*sin(t);
    UPF(:,1)=0:1/N:1;
    UPF(:,2)=0.8- 0.8*UPF(:,1) - 0.1*(sin(mod(t,4)*3.2*pi*UPF(:,1)));
    UPF = rm_dominated(UPF);
end

function R=getCPF(N,t)    %(0.5+abs(sin(t)/2))
    
        R(:,1)  = (0:1/(N-1):1)';
    R(:,2)  = 0.85 - 0.8*R(:,1) - 0.08*abs(sin(3.2*pi*R(:,1)));
    c1      = (1-0.8*R(:,1)-R(:,2)+0.08*sin(2*pi*(R(:,2)-R(:,1)/1.5))).*(1.8-1.125*R(:,1)-R(:,2)+0.08*sin(2*pi*(R(:,2)/1.8-R(:,1)/1.6)));
    invalid = c1>0;
    while any(invalid)
        R(invalid,:) = R(invalid,:).*1.001;
        c1      = (1-0.8*R(:,1)-R(:,2)+0.08*sin(2*pi*(R(:,2)-R(:,1)/1.5))).*(1.8-1.125*R(:,1)-R(:,2)+0.08*sin(2*pi*(R(:,2)/1.8-R(:,1)/1.6)));
        invalid = c1>0;
    end
    R = rm_dominated(R);
end

function R=getFesiableRegion(N,t)
    [x,y] = meshgrid(linspace(0,2,N));
    z     = nan(size(x));
    fes1  = (1-0.8*x-y+0.08*sin(2*pi*(y-x/1.5))).*(1.8-1.125*x-y+0.08*sin(2*pi*(y/1.8-x/1.6))) <= 0;
    fes2  = -(1-0.625*x-y+0.08*sin(2*pi*(y-x/1.6))).*(1.4-0.875*x-y+0.08*sin(2*pi*(y/1.4-x/1.6))) <= 0;
    z(fes1 & fes2 & 0.8*x+0.08*abs(sin(3.2*pi*x))+y>=0.85) = 0;
    R.x=x;
    R.y=y;
    R.z=z; 
end