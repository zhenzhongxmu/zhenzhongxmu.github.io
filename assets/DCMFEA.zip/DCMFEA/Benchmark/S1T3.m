function testInstance=S1T3()
    testInstance.getFesiableRegion=@getFesiableRegion;
    testInstance.getUPF=@getUPF;
    testInstance.getCPF=@getCPF;
    testInstance.getObj=@getObj;
    testInstance.getCV=@getCV;
    testInstance.getBound=@getBound;
    testInstance.M=2;
    testInstance.D=10;
end

function [LBound,UBound]=getBound(t)
    testInstance.D=10;
    G=0.5*abs(sin(t));
    LBound=zeros(1,testInstance.D);
    UBound=ones(1,testInstance.D)*(0.5+G);
end

function CV=getCV(PopObj,t)
    G=0.5*abs(sin(t));
    CV1 =(0.55+G)-PopObj(:,1)-PopObj(:,2)+0.6*sin(2*t+2*pi*sqrt(2)*PopObj(:,2)-sqrt(2)*PopObj(:,1)).^4;
    CV=[-CV1];
end

function PopObj=getObj(X,M,D,t)
    G=0.5*abs(sin(t));
    g = 1 + 0.1*abs(sum(X(:,M:D)-G,2)).^0.5 ;
    PopObj(:,1) = X(:,1);
    PopObj(:,2) = g.*(0.5+G-PopObj(:,1));
end


function UPF=getUPF(N,t)    
    G=0.5*abs(sin(t));
    UPF(:,1)=0:1/N:(0.5+G);
    UPF(:,2)=0.5+G-UPF(:,1);
end

function R=getCPF(N,t)    %(0.5+abs(sin(t)/2))
    G=0.5*abs(sin(t));
    R(:,1)  = (0:1/(N-1):1)';
    R(:,2)  =0.5+G-R(:,1);
end

function R=getFesiableRegion(N,t)
    G=0.5*abs(sin(t));
    [x,y] = meshgrid(linspace(0,1.5,N),linspace(0,1.5,N));
    z     = nan(size(x));
    fes =(0.55+G)-x-y+0.6*sin(2*t+2*pi*sqrt(2)*y-sqrt(2)*x).^4 >= 0;
    z(fes &  x+y>=0.5+G) = 0;
    R.x=x;
    R.y=y;
    R.z=z; 
end