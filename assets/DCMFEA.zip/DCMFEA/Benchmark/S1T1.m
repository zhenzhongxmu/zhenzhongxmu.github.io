function testInstance=S1T1()
    testInstance.getFesiableRegion=@getFesiableRegion;
    testInstance.getUPF=@getUPF;
    testInstance.getCPF=@getCPF;
    testInstance.getObj=@getObj;
    testInstance.getCV=@getCV;
    testInstance.M=2;
    testInstance.D=10;
    testInstance.getBound=@getBound;
end

function [LBound,UBound]=getBound(t)
    testInstance.D=10;
    G=0.5*abs(sin(t));
    LBound=zeros(1,testInstance.D);
    UBound=ones(1,testInstance.D)*(1);
end

function CV=getCV(PopObj,t)
    CV1 =1-PopObj(:,1).^2-PopObj(:,2).^2+0.5*sin(t+5*pi*sqrt(2)*PopObj(:,2)-sqrt(2)*PopObj(:,1)).^10;
    CV=[-CV1];
end

function PopObj=getObj(X,M,D,t)
    G=abs(sin(0.5*pi*t));
    g = 1 + 0.1*abs(sum(X(:,M:D)-G,2)).^0.5 ;
    PopObj(:,1) = X(:,1);
    PopObj(:,2) = g.*sqrt(1-PopObj(:,1).^2);
end

function UPF=getUPF(N,t)    
    UPF(:,1)=0:1/N:1;
    UPF(:,2)=sqrt(1-UPF(:,1).^2);
end

function R=getCPF(N,t)    %(0.5+abs(sin(t)/2))
    R(:,1)  = (0:1/(N-1):1)';
    R(:,2)  = sqrt(1-R(:,1).^2);
end


function R=getFesiableRegion(N,t)
    [x,y] = meshgrid(linspace(0,1.5,N),linspace(0,1.5,N));
    z     = nan(size(x));
    fes =1-x.^2-y.^2+0.5*sin(t+5*pi*sqrt(2).*y-sqrt(2).*x).^10 >= 0;
    z(fes &  x.^2+y.^2>=1) = 0;
    R.x=x;
    R.y=y;
    R.z=z; 
end
% 
% function R=getFesiableRegion(N,t)
%     [x,y] = meshgrid(linspace(0,1.5,N),linspace(0,1.5,N));
%     z     = nan(size(x));
%     fes =1-x.^2-y.^2+1*sin(t+3*sqrt(2).*y-sqrt(2).*x).^4 >= 0;
%     z(fes &  x.^2+y.^2>=1) = 0;
%     R.x=x;
%     R.y=y;
%     R.z=z; 
% end