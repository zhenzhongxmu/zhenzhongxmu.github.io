function newGANNSGA2(Global)

    % ��������whileΪ���ǹ����Ŀ�ܣ���������4��11�У���while���polution����Ϊ����Algorithm1�еı���initP��
    gen=1;
    select=[];
    classNum=3;
    [Z,Global.N] = UniformPoint(Global.N,Global.M);
    Population   = Global.Initialization();
    Zmin         = min(Population(all(Population.cons<=0,2)).objs,[],1); 
    while Global.evaluated<=ceil(Global.evaluation*0.1)
        MatingPool = TournamentSelection(2,Global.N,sum(max(0,Population.cons),2));
        Offspring  = Global.Variation(Population(MatingPool));
        fprintf('Global.evaluated:"%f",Global.evaluation*0.1:"%f"\n',Global.evaluated, Global.evaluation*0.1);
        Population = EnvironmentalSelection22([Population,Offspring],Global.N);
        Rank=computeRank(Population);
        for i=1:length(Rank)
            POP(i,:)=Population(i).dec; 
        end
        
        Population=Population(1,NDSort(Population.objs,1)==1);
        for i=1:length(Population)
            POS(i,:)=Population(i).dec; 
        end

        [manifoldData,~,~] = pca_d(POS,Global.M-1);
    
%         manifoldData = kpca(POS',Global.M-1);
        [label,centroid] = kmeans(manifoldData,classNum);
       
        [individualsT1,individualsT2,individualsT3]=manifoldinterpolating(POS,label,classNum);
        tempindividuals= [individualsT1;individualsT2;individualsT3];
        
        [interpManifoldData,~,~] = pca_d(tempindividuals,Global.M-1);
        
%         interpManifoldData = kpca(tempindividuals',Global.M-1);
        newPopulation=manifoldSelect(manifoldData',label,interpManifoldData',centroid,tempindividuals);
        Population = [Population INDIVIDUAL(newPopulation)];   
        Population=Population(1,NDSort(Population.objs,1)==1);
    end
    
    
    gen=1;

    [wD,SubN,Operator] = Global.ParameterSet(10,30,2);
    while Global.NotTermination(Population)
        
        Population = subNSGAII(Population,Operator,Global.N,Global);
        pop{gen} = Population(1,NDSort(Population.objs,1)==1);
        gen=saveMetrics(pop{gen}.objs,Global,gen);
    end%gen
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 
end

function [data_PCA, COEFF, sum_explained]=pca_d(data,k)
% k:ǰk�����ɷ�
data=zscore(data);  %��һ������
[COEFF,SCORE,latent,tsquared,explained,mu]=pca(data);
data= bsxfun(@minus,data,mean(data,1));
data_PCA=data*COEFF(:,1:k);
sum_explained=sum(explained(1:k));
end

function Rank=computeRank(Population)
    for i=1:length(Population)
        PopF(i,:)=Population(i).obj; 
    end
    [Rank,~,~] = fastNonDominatedSort(PopF);
    for i=1:size(Rank,2)
        if Rank(i)~=1
           Rank(i)=-1;
        end
    end
end

function Population = subNSGAII(Population,Operator,N,Global)
% Sub-optimizer in LSMOF (NSGA-II)

%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

% This function is written by Cheng He
    
    FrontNo  = NDSort(Population.objs,inf);
    CrowdDis = CrowdingDistance(Population.objs,FrontNo);
    if Operator == 1
        MatingPool = TournamentSelection(2,N,FrontNo,-CrowdDis);
        Offspring  = GA(Population(MatingPool));
    else
        MatingPool1 = TournamentSelection(2,N,FrontNo,-CrowdDis);
        MatingPool2 = TournamentSelection(2,N,FrontNo,-CrowdDis);
        MatingPool3 = TournamentSelection(2,N,FrontNo,-CrowdDis);
        Offspring   = ThisDE(Population(MatingPool1),Population(MatingPool2),Population(MatingPool3),Global);
    end
    Population = EnvironmentalSelectionLSMOF([Population,Offspring],N);
end


function Offspring = ThisDE(Parent1,Parent2,Parent3,Global)

    %% Parameter setting
    
    
    [CR,F,proM,disM] = deal(1,0.5,1,20);
    
    if isa(Parent1(1),'INDIVIDUAL')
        calObj  = true;
        Parent1 = Parent1.decs;
        Parent2 = Parent2.decs;
        Parent3 = Parent3.decs;
    else
        calObj = false;
    end
    [N,D]  = size(Parent1);
  

    %% Differental evolution
    Site = rand(N,D) < CR;
    Offspring       = Parent1;
    Offspring(Site) = Offspring(Site) + F*(Parent2(Site)-Parent3(Site));

    %% Polynomial mutation
    Lower = repmat(Global.lower,N,1);
    Upper = repmat(Global.upper,N,1);
    Site  = rand(N,D) < proM/D;
    mu    = rand(N,D);
    temp  = Site & mu<=0.5;
    Offspring       = min(max(Offspring,Lower),Upper);
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
                      (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp = Site & mu>0.5; 
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
                      (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
    if calObj
        Offspring = INDIVIDUAL(Offspring);
    end
end

