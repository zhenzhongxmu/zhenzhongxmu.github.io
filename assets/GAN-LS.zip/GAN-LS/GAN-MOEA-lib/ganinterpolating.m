function individuals=ganinterpolating(noise_x,noise_y,generator)%num*dim
    for i=1:size(noise_x,2)
        noise(i,:)=[noise_x(1,1:i) noise_y(1,i+1:size(noise_y,2))];
    end
    noise(i+1,:)=noise_x;
    noise(i+2,:)=noise_y;
    generator = nnff(generator, noise);
    individuals = generator.layers{generator.layers_count}.a;
end

function nn = nnff(nn, x)
    nn.layers{1}.a = x;
    for i = 2 : nn.layers_count
        input = nn.layers{i-1}.a;
        w = nn.layers{i}.w;
        b = nn.layers{i}.b;
        nn.layers{i}.z = input*w + repmat(b, size(input, 1), 1);
        if i ~= nn.layers_count
            nn.layers{i}.a = relu(nn.layers{i}.z);
        else
            nn.layers{i}.a = sigmoid(nn.layers{i}.z);
        end
    end
end

% sigmoid�����
function output = sigmoid(x)
    output =1./(1+exp(-x));
end
% relu
function output = relu(x)
    output = max(x, 0);
end