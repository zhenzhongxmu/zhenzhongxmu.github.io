function newpop = manifoldSelect(manifoldData,label,interpManifoldData,centroid,pop)
    newpop=[];
    distance=[];
    manifoldDistance=[];
    centroid=centroid';
    for i=1:size(interpManifoldData,2)
        for j=1:size(centroid,2)
            distance(i,j)=norm(interpManifoldData(:,i)-centroid(:,j));
            
        end
    end
    for i=1:size(interpManifoldData,2)
        sortDis=sort(distance(i,:));
        manifoldDistance(i)=sortDis(1)+sortDis(2);
    end
    
    [~,index]=sort(manifoldDistance);
    

        for i=1:40
            newpop(i,:)=pop(index(i),:);
        end
  
   
end
