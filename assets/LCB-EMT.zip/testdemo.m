clc
clear all
obj = py.importlib.import_module('AdaptiveTransfer');
py.importlib.reload(obj);
task_source_dim=20;
task_target_dim=20;
popsize=30;
testpopsize=100;
popX_source=randn(popsize, task_source_dim);% size of population: 30
popX_target=randn(popsize, task_target_dim); % size of population: 30
popY_source=randn(1, popsize);
popY_target=randn(1, popsize);
popX_source=reshape(popX_source,[1,popsize*task_source_dim]);
popX_target=reshape(popX_target,[1,popsize*task_target_dim]);
candidate_pool=randn(testpopsize, task_source_dim); 
candidate_pool=reshape(candidate_pool,[1, testpopsize*task_source_dim]);
transferred_pop=py.AdaptiveTransfer.transferPop(popX_source,popY_source,popX_target,popY_target,candidate_pool,task_source_dim,task_target_dim,75);
for j=1:length(transferred_pop)
    p=cellfun(@double,cell(transferred_pop{j}))
end
